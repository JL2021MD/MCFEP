oldseed=$(awk '/seed/ {print $3; exit}' $1)
echo "Old seed is $oldseed."

if [ $# -ge 2 ] && [[ $2 =~ ^[0-9]+$ ]]; then
    newseed=$2
else
    newseed=$((1000 + RANDOM % 9999))
fi

sed -i "/seed/c\         seed = $newseed" $1
newseed=$(awk '/seed/ {print $3; exit}' $1)
echo "New seed is $newseed."
