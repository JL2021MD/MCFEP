#!/usr/bin/python3
import sys
import os
import csv
fc=5
arg1 = sys.argv[1]
if len(sys.argv) == 3:
    fc = sys.argv[2]
ref=open(arg1,"r")
save=open("inter.txt","w")

restrain="restrain = [ "
insertlist=[0]
for line in ref:
    if "ATOM" in line and list(line)[77] != "H":
        atom=''.join(list(line)[12:16])
        res_ins=list(line)[26]
        res_num=''.join(list(line)[22:26])
        chain=list(line)[21]
        x=''.join(list(line)[30:38])
        y=''.join(list(line)[38:46])
        z=''.join(list(line)[46:54])
        if res_ins != " ":
            restrain=restrain+f'{{atom = \"asl:chain.name {chain} and res.num {res_num} and res.ins {res_ins} and atom. {atom}\" fc = {fc} ref=[{x} {y} {z} ]}}\n            '    
            if insertlist[-1] != res_num:
                insertlist.append(res_num)
        else:
            restrain=restrain+f'{{atom = \"asl:chain.name {chain} and res.num {res_num} and atom. {atom}\" fc = {fc} ref=[{x} {y} {z} ]}}\n            '
    if "HETATM" in line and list(line)[77] != "H":
        atom=''.join(list(line)[12:16])
        res_name=''.join(list(line)[17:21])
        res_num=''.join(list(line)[22:26])
        x=''.join(list(line)[30:38])
        y=''.join(list(line)[38:46])
        z=''.join(list(line)[46:54])        
        restrain=restrain+f'{{atom = \"asl:res. {res_name} and res.num {res_num} and atom. {atom}\" fc = {fc} ref=[{x} {y} {z} ]}}\n            '
print(restrain, file=save)
#print(insertlist)

ref.close()
save.close()

for res in insertlist[1:]:
# if your structure contains letter insert residues.
    os.system(f'''sed -i "s/res.num {res} and atom/res.num {res} and not res.ins * and atom/g" inter.txt ''') 

os.system('''sed '/output from gen_restraints.py/r inter.txt' common/restraint.tmpl.empty > restraint.tmpl''')

