for repeat in run2 run3 ; do
mkdir $repeat
laststage=$(ls *tgz | rev | cut -c 9 | tail -n 1)
cd $repeat


cp ../../common/randomseed.sh .
cp -s ../custom*.opls . 2>/dev/null
cp ../{restart.sh,*-multisim_checkpoint,*_complex.msj} .
ln -s ../*complex_$laststage-out.tgz ;
bash randomseed.sh *msj ;
cd ..
done
