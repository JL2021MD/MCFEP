current=`pwd`
ref=$(ls $current/../*.pdb)
printf "The current reference file (morphing target) is \n$ref \n\n"
printf "The current folder is \n$current  \n\n "

lastfolder=$(ls -d pull_? | sort -V | tail -n 1)
cd $lastfolder
laststage=$(ls *tgz | rev | cut -c 9 | tail -n 1)
tar -xf *complex_$laststage-out.tgz 

if which cpptraj >/dev/null 2>&1; then
    printf "\ncpptraj found, performing RMSD measurements. Visual inspection needed for final verdict. Output files from all 4 windows are now being linked to current folder.\n\n"
    skip=0
else
    printf "\ncpptraj not found, skipping RMSD measurements. Use visual inspection as final verdict. Output files from all 4 windows are now being linked to current folder.\n\n"
    skip=1
fi

for win in 0 1 2 3 ; do
for i in $laststage ; do
cd $current/$lastfolder/*_*_*_complex_fep1/*complex_${i}_lambda$win

if [ "$skip" -eq 0 ]; then

outname=out.$i.$win
intraj=*_lambda$win.xtc
extract="protein or ligand"

echo "Processing window $win to convert to a compatible trajectory for RMSD measurements."
## using trj2mae.py to retain the solute only. Output is single PDBs, which also removes virtual sites.
$SCHRODINGER/run trj2mae.py *lambda$win-out.cms.gz $intraj $outname -extract-asl "$extract" -align-asl '' -out-format pdb -separate

frames=`ls $outname*.pdb | wc -l`

ref=$ref
## RMSD with cpptraj
cat >cpptraj.RMSD.in<<EOF
parm $ref [1]
parm ${outname}_0.pdb [2]

reference $ref  parm [1]
EOF


j=0
while [ $j -lt $frames ]
do
echo  "trajin ${outname}_$j.pdb parm [2]" >> cpptraj.RMSD.in
j=$(($j+1))

done
ligresname=6GC
ligresnum=301
lig0=6G7     # only works if your ref PDB file contains lig0
lig0resnum=301
if grep -q "$ligresname " ${outname}_0.pdb && grep -q "HETATM" ${outname}_0.pdb ; then
printf "Deteced small molecule in RMSD measurement region.\n\n"

autoregion=1 ## to automatically grab residues near the ligand region for RMSD measurements

if [ $autoregion -eq 1 ] ; then
cutoff=3
readarray -t proteinlist < <(python3 $current/../common/getres.py $ref $ligresname $cutoff )

#proteinlist=${proteinlist%,}
echo $proteinlist

cat >>cpptraj.RMSD.in<<EOF
rms protein :;$proteinlist&!@H= reference nofit out ../rmsd$i.$win.out
rms backbone :;$proteinlist&@CA,C,N,O reference nofit out ../rmsd$i.$win.out
rms sidechains  :;$proteinlist&!@CA,C,N,O,H= reference nofit out ../rmsd$i.$win.out

rms ligand :;$ligresnum&:$ligresname&!@H= reference nofit out ../rmsd$i.$win.out  
rms lig0 :;$lig0resnum&:$lig0&!@H= reference nofit out ../rmsd$i.$win.out  
EOF
IFS=','
for res in $proteinlist; do
echo "rms $res :;$res&!@H= reference nofit out ../rmsd$i.$win.out " >> cpptraj.RMSD.in
done
IFS=$' \t\n'
else
cat>>cpptraj.RMSD.in<<EOF



## 5J9X small ligand template
rms protein :;104-110&!@H= reference nofit out ../rmsd$i.$win.out
rms backbone :;104-110&@CA,C,N,O reference nofit out ../rmsd$i.$win.out
rms sidechains  :;104-110&!@CA,C,N,O,H= reference nofit out ../rmsd$i.$win.out


rms ligand :;$ligresnum&:$ligresname&!@H= reference nofit out ../rmsd$i.$win.out  
rms 104 :;104&!@H= reference nofit out ../rmsd$i.$win.out  
rms 105 :;105&!@H= reference nofit out ../rmsd$i.$win.out  
rms 106 :;106&!@H= reference nofit out ../rmsd$i.$win.out 
rms 107 :;107&!@H= reference nofit out ../rmsd$i.$win.out 
rms 108 :;108&!@H= reference nofit out ../rmsd$i.$win.out 
rms 109 :;109&!@H= reference nofit out ../rmsd$i.$win.out 
rms 110 :;110&!@H= reference nofit out ../rmsd$i.$win.out 
rms 111 :;111&!@H= reference nofit out ../rmsd$i.$win.out 
EOF
fi

else

cat>>cpptraj.RMSD.in<<EOF
## ACE2/RBD Q498 protein-protein template
rms protein ::E&:;501&!@H=|::E&:;498&:ARG&!@H=|::A&:;353,355,41,38&!@H= reference nofit out ../rmsd$i.$win.out
rms backbone ::E&:;501&@CA,C,N,O|::E&:;498&:ARG&@CA,C,N,O|::A&:;353,355,41,38&@CA,C,N,O reference nofit out ../rmsd$i.$win.out
rms sidechains  ::E&:;501&!@CA,C,N,O,H=|::E&:;498&:ARG&!@CA,C,N,O,H=|::A&:;353,355,41,38&!@CA,C,N,O,H= reference nofit out ../rmsd$i.$win.out
rms 498 ::E&:;498&:ARG&!@H= reference nofit out ../rmsd$i.$win.out 
rms 501 ::E&:;501&!@H= reference nofit out ../rmsd$i.$win.out  
rms 41 ::A&:;41&!@H= reference nofit out ../rmsd$i.$win.out  
rms 38 ::A&:;38&!@H= reference nofit out ../rmsd$i.$win.out 
rms 353 ::A&:;353&!@H= reference nofit out ../rmsd$i.$win.out 
rms 355 ::A&:;355&!@H= reference nofit out ../rmsd$i.$win.out
EOF
for pdb in *pdb; do awk '!seen[substr($0, 13)]++' $pdb > tmpfile && mv tmpfile $pdb ; done  # to remove duplicate atoms in the ligand (solvent leg solute) from lambda
fi
cpptraj cpptraj.RMSD.in 1>/dev/null
rm $outname*.pdb
fi
current2=`pwd`
if [ "$skip" -eq 0 ]; then
printf "\n\nWindow $win RMSD \n" >$current/rmsd$i.$win.out
cat  ../rmsd$i.$win.out >> $current/rmsd$i.$win.out
fi
cd $current
ln -s ${current2#$current/}/*lambda?-out.cms.gz win$win-out.cms.gz
ln -s ${current2#$current/}/*xtc



done
done
if [ "$skip" -eq 0 ]; then
cat rmsd*.out
fi
printf "\n\n****User message: Choose the window that properly matches (RMSD < ~0.7) morphing target, and also matches the closest. Windows 1 or 2 is preferred. If your lig1 completely included the structure of lig0, window 3 is also good, otherwise windows 0 or 3 have an increased chance that the non-existant ligand may cause a simulation crash once applied to the entire half of the lambda windows in the next step. In that case, choose a different window or rerun the lambda1 pulling stage with adjustments. Next, set the chosen window in the 1.link.sh script and run it.\n"

