subhost=gpu-a4500
random_seed=$((1000 + RANDOM % 9999))
if [ ! -f mutations.txt ]; then
printf "Did not detect mutations.txt file, assuming this is small molecule FEP.\n"
#### For starting small molecule MCFEP
default_fmp=$(ls *.fmp | head -n 1)  # to get the first .fmp file if an fmp file is not specified by user
ensemble=muVT
for i in $@ ; do
if [[ "$i" == *"seed"* ]]; then
    extracted_number=$(echo $i | grep -o "[0-9]*")
    seed=$extracted_number
fi
if [[ "$i" == *"gpu"* ]]; then
    extracted_number=$(echo "$i" | grep -o "[0-9]*" )
    gpu=$extracted_number
fi
if [[ "$i" == "fmp="* ]]; then
    userfmp="${i#*=}"
fi
done
seed=${seed:-$random_seed}    ;    gpus=${gpu:-1} ; echo Random seed is $seed ;  echo Number of GPUs is $gpus 
fmp=${userfmp:-$default_fmp}
jobname=${fmp%.fmp}
echo Input fmp file is $fmp

if [ ! -f *.tmpl ]; then
	read -p "restraint.tmpl not found. Proceed anyway? y/n " user_input
	if [[ "$user_input" == "n" ]]; then
		echo "Exiting..."
    		exit 1
	fi
fi

if [ ! -f *.pdb ]; then read -p "Reference PDB not found. Proceed anyway? y/n " user_input ; 
	if [[ "$user_input" == "n" ]]; then
		echo "Exiting..."
    		exit 1
	fi
fi



ff=$(ls custom*.opls 2>/dev/null) 
if [ -n "$ff" ]; then
        ffstring="-OPLSDIR $ff"
	printf "Detected force field file, adding $ffstring to launch.\n"
else
	printf "Did not detect force field file, not adding to launch.\n"
fi

##### The actual FEP submit command for the lambda0 prepare #########
"${SCHRODINGER}/fep_plus" -HOST localhost -SUBHOST $subhost -ppj $gpus -time 25000 -ensemble $ensemble -seed $seed -custom-charge-mode assign -lambda_windows 12 -core_hopping_lambda_windows 16 -charged_lambda_windows 24 $ffstring -JOBNAME $jobname $fmp -TMPLAUNCHDIR -skip-leg solvent -prepare > launch.sh

current=`pwd`



sed -i 's/Launch command: //g' launch.sh
sed -i 's/-RETRIES 1/-RETRIES 0/g' launch.sh
sed -i 's/rezero_system = true/rezero_system = false/g' *_*.msj #It is better if the WTstart is already pre-zeroed though. To pre-zero the start, writing a system builder job from maestro will generate a zeroed mae file.

sed -i '/  fep_type =/a \ \ bennett.sliding_time.window=1000\n    bennett.sliding_time.begin=100\n    bennett.sliding_time.dt=1000' *_*.msj #set the sliding energy window to a 1ns length

#insert stop command after 1st eq stage for the lambda0 complex
sed -i 's/      title = "Brownian Dynamics NVT, T = 10/      title = "Brownian Dynamics NVT, T=10/g' *_complex.msj
sed -i '/title = "Brownian Dynamics NVT, T = 10 K/{n;a\stop{} \n
}' *_complex.msj
sed -i 's/-1 -3/-1 -3 -4/g' *_*.msj  # to save also the final equilibration  for analysis, if needed


#Continue for preparing the lambda1 complex
mkdir lbda1
echo "echo \"Run lbda1/launch.sh to build lambda1 conformer\"" >> launch.sh
cd lbda1
lbda1jobname=pull
ln -s ../$ff 2>/dev/null
ln -s ../$fmp
ln -s ../${jobname}_pv.maegz
ln -s ../*tmpl
cp ../${jobname}_complex.msj ${lbda1jobname}_complex.inter.msj
cp ../${jobname}_chg_complex.msj ${lbda1jobname}_chg_complex.inter.msj
cp ../${jobname}_corehopping_complex.msj ${lbda1jobname}_corehopping_complex.inter.msj
cp ../${jobname}_fragment_linking_complex.msj ${lbda1jobname}_fragment_linking_complex.inter.msj
cp ../${jobname}.msj $lbda1jobname.msj

msj=$lbda1jobname.msj

sed -i 's/default:12/default:4/g' ${lbda1jobname}_complex.inter.msj  ## to minimize the number of windows to save time
sed -i 's/charge:24/charge:4/g' ${lbda1jobname}_chg_complex.inter.msj
sed -i 's/flexible:16/flexible:4/g' ${lbda1jobname}_corehopping_complex.inter.msj
sed -i 's/      time = 100/      time = 10/g' ${lbda1jobname}*_complex.inter.msj
sed -i 's/      time = 240/      time = 24/g' ${lbda1jobname}*_complex.inter.msj
sed -i 's/stop/#stop/g' ${lbda1jobname}*_complex.inter.msj

#edits to the parent msj file to skip the solvent and vacuum leg and use the new jobname
sed -i '/solvent/d' $msj
sed -i '/vacuum/d' $msj
#sed -i '/     charge0 =/,+4d' $msj
#sed -i '/     core-hopping =/,+4d' $msj
#sed -i '/     fragment-linking =/,+5d' $msj
#sed -i '/     macrocycle-core-hopping =/,+4d' $msj
#sed -i 's/should_skip = false/should_skip = true/g' $msj
#sed -i 's/skip_legs = \[vacuum \]/skip_legs = \[solvent vacuum \]/g' $msj
sed -i "s/${jobname}_/${lbda1jobname}_/g" $msj



###Add restraints
for type in ${lbda1jobname}_*.inter.msj  ; do
sed '/#stop/r restraint.tmpl' $type >${type%.inter.msj}.msj
done


cat>launch.sh<<EOF
$SCHRODINGER/utilities/multisim ${jobname}_pv.maegz -HOST localhost -SUBHOST $subhost -JOBNAME $lbda1jobname -maxjob 0 -m pull.msj -RETRIES 0 $ffstring
echo "Once the job is completed, run 1.view.sh to extract the relevant morphed structures for comparing to target structure."
EOF

cp $current/common/1.view.sh .

cd $current

cat>1.link.sh<<EOF

sed -i 's/stop/#stop/g' ${jobname}*_complex.msj
window=2
printf "Copying over the conformer from window \$window.\n\n"
cd ${jobname}_4 
tar -xf *complex_6-out.tgz 
tar=\$(ls *complex_6-out.tgz)
mv \$tar \$tar.old --no-clobber -v
rm -v *checkpoint_6
cd *complex_fep1/
cp ../../lbda1/${lbda1jobname}_4/*complex_fep1/*complex_7_lambda\$window/*out.cms.gz .
source=*-out.cms.gz


read -p "Please specify the number of total windows(perturbation type). 12(Default); 16(Core-Hopping); 24(Charge-changing): " user_input ; 
	if [[ "\$user_input" != "12" && "\$user_input" != "16" && "\$user_input" != "24" ]]; then
		echo "Please manually modify code to accommodate \$user_input windows."
    		exit 1
	fi

if [[ "\$user_input" == "12" ]] ; then
printf "\n\n****User message: \$user_input windows in total for non-charge changing default perturbations.\n"
for i in {6..11}; do  ## 12 windows in total here
cd *lambda\$i
ln -sf ../\$source *lambda\$i-out.cms.gz -v
cd ..
done
cd ..
tar -cf  \$tar *complex_fep1
cp ../${jobname}_complex.msj .
printf "\n\n****User message: FEP will continue using ${jobname}_complex.msj.\n"
fi

if [[ "\$user_input" == "16" ]] ; then
printf "\n\n****User message: \$user_input windows in total for core-hopping perturbations.\n"
for i in {8..15}; do  ## 16 windows in total here
cd *lambda\$i
ln -sf ../\$source *lambda\$i-out.cms.gz -v
cd ..
done
cd ..
tar -cf  \$tar *complex_fep1
cp ../${jobname}_corehopping_complex.msj .
printf "\n\n****User message: FEP will continue using ${jobname}_corehoppping_complex.msj.\n"
fi

if [[ "\$user_input" == "24" ]] ; then
printf "\n\n****User message: \$user_input windows in total for charge changing perturbations.\n"
for i in {12..23}; do  ## 24 windows in total here
cd *lambda\$i
ln -sf ../\$source *lambda\$i-out.cms.gz -v
cd ..
done
cd ..
tar -cf  \$tar *complex_fep1
cp ../${jobname}_chg_complex.msj .
printf "\n\n****User message: FEP will continue using ${jobname}_chg_complex.msj.\n"
fi


cp -s ../custom*.opls .

printf "\n\n****User message: If moving files to another location to continue run, copy the common directory and the following files in cd ${jobname}_4/ : \$tar ${jobname}*_complex.msj *-multisim_checkpoint restart.sh custom*.opls "
printf "\n\n****User message: To undo the whole step of copy conformers, replace the new \$tar file with the \$tar.old and delete the *fep1 directory.\n"
printf "\n\n****User message: For this example run using HSP90 ligands, a 25ns protein relaxation is used instead of a default 1ns unrestrained relaxation. This helps better relax the small pocket that has the large ligand fitted in with steric clashes. To add the 25ns relaxation stage, run ${jobname}_4/2.insert25ns.sh before continuing the FEP job. \n"
printf "\n\n****User message: To make repeat run directories, run ${jobname}_4/3.repeat.sh." 
printf "\n\n****User message: To continue the FEP, run ${jobname}_4/restart.sh for each directory.\n" 

EOF
### adding 1ns relaxation after pull
sed -i '0,/time = 20/s//time = 20.0000/' ${jobname}*_complex.msj
#sed -i '/gcmc =/,/solute_heavy_atom/s/solute_heavy_atom/backbone/' ${jobname}*_complex.msj
sed -i '/time = 20.0000/,${/time = 20$/s//time = 1000/}' ${jobname}*_complex.msj
if [ $ensemble = "NVT" ]; then sed -i '/stop/r common/1nsNVTrelax.stage' ${jobname}*_complex.msj ; fi

mkdir ${jobname}_4
cd ${jobname}_4
cat>restart.sh<<EOF
tar2=\$(ls *complex_6-out.tgz)
job=\${tar2%_6-out.tgz}
msj=*.msj
\$SCHRODINGER/utilities/multisim -HOST localhost -SUBHOST $subhost -JOBNAME \$job -RESTART \${job}-multisim_checkpoint:7 -d \$tar2 -m \$msj -RETRIES 0 $ffstring # -set 'stage[1].set_family.remd.total_proc=4' -maxjob 4

EOF
if [  -f ../5j64to5j9x.fmp ]; then ln -s ../common/insert25ns.sh 0.insert25ns.sh ; fi    ## to insert the 25ns relaxation stage specific for the Hsp90 ligands in the example.
ln -s ../common/repeat.sh     1.createrepeat.sh
printf "\n\nRun launch.sh to start the FEP for lambda0 prepare.\n"

echo "Run lbda1/launch.sh to build lambda1 conformer"
exit









else
printf "Detected mutations.txt, starting protein FEP.\n"
    ############ For starting protein MCFEP, now unified in a single fep.sh file.  ############
#shopt -s nullglob
default_mae=$(ls *.mae *maegz 2>/dev/null | head -n 1    )  # to get the first .mae or .maegz file if it is not specified by user

for i in $@ ; do
if [[ "$i" == *"seed"* ]]; then
    extracted_number=$(echo $i | grep -o "[0-9]*")
    seed=$extracted_number
fi
if [[ "$i" == *"gpu"* ]]; then
    extracted_number=$(echo "$i" | grep -o "[0-9]*" )
    gpu=$extracted_number
fi
if [[ "$i" == "mae="* ]]; then
    usermae="${i#*=}"
fi
done
seed=${seed:-$random_seed}    ;    gpus=${gpu:-4} ; echo Random seed is $seed ;  echo Number of GPUs is $gpus 
mae=${usermae:-$default_mae}
fullfolder=$(basename `pwd`)
jobname=$fullfolder     #using the folder name as the default jobname
echo Input mae file is $mae

if [ ! -f *.tmpl ]; then
	read -p "restraint.tmpl not found. Proceed anyway? y/n " user_input
	if [[ "$user_input" == "n" ]]; then
		echo "Exiting..."
    		exit 1
	fi
fi

if [ ! -f *.pdb ]; then read -p "Reference PDB not found. Proceed anyway? y/n " user_input ; 
	if [[ "$user_input" == "n" ]]; then
		echo "Exiting..."
    		exit 1
	fi
fi

##### The actual FEP submit command for the lambda0 prepare #########
$SCHRODINGER/fep_plus -HOST localhost -SUBHOST $subhost -JOBNAME $jobname -ppj $gpus $mae -protein mutations.txt -solvent_asl "chain.name E" -skip-leg solvent -time 25000 -seed $seed -prepare > launch.sh

current=`pwd`



sed -i 's/Launch command: //g' launch.sh
sed -i 's/-RETRIES 1/-RETRIES 0/g' launch.sh
sed -i 's/rezero_system = true/rezero_system = false/g' *_*.msj #It is better if the WTstart is already pre-zeroed though. To pre-zero the start, writing a system builder job from maestro will generate a zeroed mae file.

sed -i '/  fep_type =/a \ \ bennett.sliding_time.window=1000\n    bennett.sliding_time.begin=100\n    bennett.sliding_time.dt=1000' *_*.msj #set the sliding energy window to a 1ns length

#insert stop command after 1st eq stage for the lambda0 complex
sed -i 's/      title = "Brownian Dynamics NVT, T = 10/      title = "Brownian Dynamics NVT, T=10/g' *_*.msj
sed -i '/title = "Brownian Dynamics NVT, T = 10 K/{n;a\stop{} \n
}' *_*.msj
sed -i 's/-1 -3/-1 -3 -4/g' *_*.msj  # to save also the final equilibration  for analysis, if needed

#replace ligand keywords
sed -i 's/ligand_selectivity/protein_selectivity/g' *.msj
#sed -i 's/mode = assign/mode = keep/g' *.msj


#Continue for preparing the lambda1 complex
mkdir lbda1
echo "echo \"Run lbda1/launch.sh to build lambda1 conformer\"" >> launch.sh
cd lbda1
lbda1jobname=pull
ln -s ../$mae
ln -s ../*tmpl restraint.tmpl
ln -s ../mutations.txt
cp ../${jobname}_chg_complex.msj ${lbda1jobname}_chg_complex.inter.msj
cp ../${jobname}_complex.msj ${lbda1jobname}_complex.inter.msj
cp ../${jobname}_corehopping_complex.msj ${lbda1jobname}_corehopping_complex.inter.msj
cp ../${jobname}_membrane.msj ${lbda1jobname}_membrane.inter.msj 2>/dev/null
cp ../${jobname}.msj $lbda1jobname.msj

msj=$lbda1jobname.msj

sed -i 's/default:12/default:4/g' ${lbda1jobname}_complex.inter.msj  ## to minimize the number of windows to save time
sed -i 's/charge:24/charge:4/g' ${lbda1jobname}_chg_complex.inter.msj
sed -i 's/flexible:16/flexible:4/g' ${lbda1jobname}_corehopping_complex.inter.msj
sed -i 's/      time = 100/      time = 10/g' ${lbda1jobname}*_complex.inter.msj
sed -i 's/stop/#stop/g' ${lbda1jobname}*_complex.inter.msj

#edits to the parent msj file to skip the solvent leg and use the new jobname
sed -i '/solvent/d' $msj
sed -i "s/${jobname}_/${lbda1jobname}_/g" $msj



###Add restraints
for type in ${lbda1jobname}_*.inter.msj  ; do
sed '/#stop/r restraint.tmpl' $type >${type%.inter.msj}.msj 
done

cat>launch.sh<<EOF
$SCHRODINGER/utilities/multisim $mae -HOST localhost -SUBHOST $subhost -JOBNAME $lbda1jobname -maxjob 0 -lic PSP_PLOP:8 -lic MMOD_MACROMODEL:2 -m $msj -RETRIES 0
echo "Once the job is completed, run 1.view.sh to extract the relevant morphed structures for comparing to target structure."
EOF

cp $current/common/1.view.sh .

cd $current

if [  -f  *membrane.msj ] ; then mkdir ${jobname}_6 ; mainfolder=${jobname}_6; else mkdir ${jobname}_5 ; mainfolder=${jobname}_5 ; fi


cat>1.link.sh<<EOF
sed -i 's/stop/#stop/g' ${jobname}*_complex.msj
window=2
printf "Copying over the conformer from window \$window.\n\n"
current=\`pwd\`
cd \$current/$mainfolder
tar -xf *complex_8-out.tgz
tar=\$(ls *complex_8-out.tgz)
mv \$tar \$tar.old  --no-clobber -v
rm -v *checkpoint_8
cd \$current/$mainfolder/*complex_fep1/
cp ../../lbda1/pull_?/*complex_fep1/*complex_9_lambda\$window/*out.cms.gz .
source=*-out.cms.gz

read -p "Please specify the number of total windows(perturbation type). 12(Default); 16(Core-Hopping); 24(Charge-changing): " user_input ; 
	if [[ "\$user_input" != "12" && "\$user_input" != "16" && "\$user_input" != "24" ]]; then
		echo "Please manually modify code to accommodate \$user_input windows."
    		exit 1
	fi

if [[ "\$user_input" == "12" ]] ; then
printf "\n\n****User message: \$user_input windows in total for non-charge changing default perturbations.\n"
for i in {6..11}; do  ## 12 windows in total here
cd *lambda\$i
ln -sf ../\$source *lambda\$i-out.cms.gz -v
cd ..
done
cd ..
tar -cf  \$tar *complex_fep1
cp ../${jobname}_complex.msj .
printf "\n\n****User message: FEP will continue using ${jobname}_complex.msj.\n"
fi

if [[ "\$user_input" == "16" ]] ; then
printf "\n\n****User message: \$user_input windows in total for core-hopping perturbations.\n"
for i in {8..15}; do  ## 16 windows in total here
cd *lambda\$i
ln -sf ../\$source *lambda\$i-out.cms.gz -v
cd ..
done
cd ..
tar -cf  \$tar *complex_fep1
cp ../${jobname}_corehopping_complex.msj .
printf "\n\n****User message: FEP will continue using ${jobname}_corehoppping_complex.msj.\n"
fi

if [[ "\$user_input" == "24" ]] ; then
printf "\n\n****User message: \$user_input windows in total for charge changing perturbations.\n"
for i in {12..23}; do  ## 24 windows in total here
cd *lambda\$i
ln -sf ../\$source *lambda\$i-out.cms.gz -v
cd ..
done
cd ..
tar -cf  \$tar *complex_fep1
cp ../${jobname}_chg_complex.msj .
printf "\n\n****User message: FEP will continue using ${jobname}_chg_complex.msj.\n"
fi

printf "\n\n****User message: If moving files to another location to continue run, copy the common directory and the following files in cd $mainfolder/ : \$tar ${jobname}_chg_complex.msj *-multisim_checkpoint restart.sh "
printf "\n\n****User message: To undo the whole step of copy conformers, replace the new \$tar file with the \$tar.old and delete the *fep1 directory.\n"
printf "\n\n****User message: To continue the FEP, run $mainfolder/restart.sh.\n" 
EOF
### adding 1ns relaxation after pull
sed -i '0,/time = 20/s//time = 20.0000/' ${jobname}*_complex.msj
sed -i '/gcmc =/,/solute_heavy_atom/s/solute_heavy_atom/backbone/' ${jobname}*_complex.msj
sed -i '/time = 20.0000/,${/time = 20$/s//time = 1000/}' ${jobname}*_complex.msj

if [ "$ensemble" == "NVT" ]; then sed -i '/stop/r common/1nsNVTrelax.stage' ${jobname}*_complex.msj ; fi



cd $mainfolder
cat>restart.sh<<EOF
tar2=\$(ls *complex_8-out.tgz)
job=\${tar2%_8-out.tgz}
msj=*.msj
\$SCHRODINGER/utilities/multisim -HOST localhost -SUBHOST $subhost -JOBNAME \$job -RESTART \${job}-multisim_checkpoint:9 -d \$tar2 -m \$msj -RETRIES 0 # -set 'stage[1].set_family.remd.total_proc=4' -maxjob 4

EOF
ln -s ../common/repeat.sh
printf "\n\nRun launch.sh to start the FEP for lambda0 prepare.\n"

echo "Run lbda1/launch.sh to build lambda1 conformer"

fi


