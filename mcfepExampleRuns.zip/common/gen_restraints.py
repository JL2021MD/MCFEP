#!/usr/bin/python3
import sys
import os
import csv
fc=5
arg1 = sys.argv[1]
if len(sys.argv) == 3:
    fc = sys.argv[2]
ref=open(arg1,"r")
save=open("inter.txt","w")

restrain="restrain = [ "
insertlist=[0]
for line in ref:
    if "ATOM" in line and line[77] != "H":
        atom=line[12:16]
        res_ins=line[26]
        res_num=line[22:26]
        chain=line[21]
        x=line[30:38]
        y=line[38:46]
        z=line[46:54]
        if res_ins != " ":
            restrain=restrain+f'{{atom = \"asl:chain.name {chain} and res.num {res_num} and res.ins {res_ins} and atom. {atom}\" fc = {fc} ref=[{x} {y} {z} ]}}\n            '    
            if res_num not in insertlist:
                insertlist.append(res_num)
        else:
            restrain=restrain+f'{{atom = \"asl:chain.name {chain} and res.num {res_num} and atom. {atom}\" fc = {fc} ref=[{x} {y} {z} ]}}\n            '
    if "HETATM" in line and line[77] != "H":
        atom=line[12:16]
        res_name=line[17:21]
        res_num=line[22:26]
        x=line[30:38]
        y=line[38:46]
        z=line[46:54]        
        restrain=restrain+f'{{atom = \"asl:res. {res_name} and res.num {res_num} and atom. {atom}\" fc = {fc} ref=[{x} {y} {z} ]}}\n            '
print(restrain, file=save)


ref.close()
save.close()

rstfile=open("restraint.tmpl","w")
print("""concatenate {
  maeff_output = {
     name = "$JOBNAME$[_replica$REPLICA$]-out.cms.gz"
  }
  print_expected_memory = true
  simulate = [

     {eneseq = {
         interval = 0.3
      }
      ensemble = {
         class = NVT
         method = Langevin
         thermostat = {
            tau = 0.1
         }
      }
      maeff_output = {
         name = "$JOBNAME$[_replica$REPLICA$]-out.cms.gz"
      }
      randomize_velocity = {
         interval = 1.0
      }
      print_restraint=true

################### Begin writing the restraints
### output from gen_restraints.py is written here. Keep this line for sed to locate.



]

      temperature = 300.0
      time = 90
      timestep = [0.001 0.001 0.003 ]
      title = "NVT, T = 10 K, small timesteps, and restraints on solute heavy atoms, 12ps"
      trajectory = {
         interval = 24.0
      }
     }
  ]
  title = "Pull into place"
}
stop{}""", file=rstfile)

rstfile.close()



for res in insertlist:
# if your structure contains letter insert residues.
    os.system(f'''sed -i "s/res.num {res} and atom/res.num {res} and not res.ins A,B,C,D,E,F,G,H,I,J,K,L and atom/g" inter.txt ''') 

#os.system('''sed '/output from gen_restraints.py/r inter.txt' common/restraint.tmpl.empty > restraint.tmpl''')
os.system('''sed -i '/output from gen_restraints.py/r inter.txt' restraint.tmpl''')

