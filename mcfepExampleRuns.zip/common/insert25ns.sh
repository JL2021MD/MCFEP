##insert the 25ns relax stage after stage 7
if ! grep -q "Relaxing pocket with ligand core held" *_complex.msj; then   # to make sure it is not inserted multiple times
    sed -i '/GCMC Solvation muVT, no restraints/{n;n;n;n;n; r ../common/25ns.stage
}' *_complex.msj
sed -i 's/time = 1000/time = 0/g' *_complex.msj
fi

if grep -q "Relaxing pocket with ligand core held" *_complex.msj ; then

printf "\n****User message: A 25ns NVT relaxation stage with only the ligand core region and 3 neighboring protein residues restrained has been added after the GCMC solvation stage. The 1ns unrestrained relaxation under GCMC is skipped.\n\n"

else
    echo "Did not successfully add 25ns relaxation stage."
fi
