import sys
pdb=open(sys.argv[1], 'r')
ligres=sys.argv[2]
if len(sys.argv) >3:
    cutoff=float(sys.argv[3])
else:
    cutoff=5
atoms=[]
class Atom:
    def __init__(self, x, y, z, atom_id, atom_name, residue_name, residue_number):
        self.x=x
        self.y=y
        self.z=z
        self.atom_id=atom_id
        self.atom_name = atom_name
        self.residue_name = residue_name
        self.residue_number = residue_number

reslist=[]



targetlines=pdb.readlines()
pdb.seek(0)
for line in pdb:
    count=1
    lig_atomlist=[]
    if line[17:20] == ligres :
        
        x1 = float(line[30:38].strip())
        y1 = float(line[38:46].strip())
        z1 = float(line[46:54].strip())
        atom_id="Atom"+str(count)
        atom_name= line[12:16].strip()
        residue_name=line[17:20].strip()
        residue_number=line[22:26].strip()
        atom=Atom(x1,y1,z1,atom_id, atom_name, residue_name, residue_number)
        atoms.append(atom)
        count+=1
        for k in targetlines:
            if k.startswith('ATOM') : 
                x2 = float(k[30:38].strip())
                y2 = float(k[38:46].strip())
                z2 = float(k[46:54].strip())
                distance=((x1-x2)**2+(y1-y2)**2+(z1-z2)**2)**0.5
                if distance < cutoff and k[22:26].strip() not in reslist:
                    reslist.append(k[22:26].strip())
reslist.sort()
for res in reslist:
    print(res, end=',')
