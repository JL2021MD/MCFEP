if [ ! -f mutations.txt ]; then
printf "Did not detect mutations.txt file, assuming this is small molecule FEP.\n"
#### For starting small molecule MCFEP (solvent leg only)
default_fmp=$(ls *.fmp | head -n 1)  # to get the first .fmp file if an fmp file is not specified by user
subhost=fgpu 

random_seed=$((1000 + RANDOM % 9999))
for i in $1 $2 $3; do
if [[ "$i" == *"seed"* ]]; then
    extracted_number=$(echo $i | grep -o "[0-9]*")
    seed=$extracted_number
fi
if [[ "$i" == *"gpu"* ]]; then
    extracted_number=$(echo "$i" | grep -o "[0-9]*" )
    gpu=$extracted_number
fi
if [[ "$i" == "fmp="* ]]; then
    userfmp="${i#*=}"
fi
done
seed=${seed:-$random_seed}    ;    gpus=${gpu:-1} ; echo Random seed is $seed ;  echo Number of GPUs is $gpus 
fmp=${userfmp:-$default_fmp}
jobname=${fmp%.fmp}
echo Input fmp file is $fmp


ff=$(ls custom*.opls 2>/dev/null) 
if [ -n "$ff" ]; then
        ffstring="-OPLSDIR $ff"
	printf "Detected force field file, adding $ffstring to launch.\n"
else
	printf "Did not detect force field file, not adding to launch.\n"
fi


"${SCHRODINGER}/fep_plus" -HOST localhost -SUBHOST $subhost -ppj $gpus -time 25000 -ensemble muVT -seed $seed -custom-charge-mode assign -lambda_windows 12 -core_hopping_lambda_windows 16 -charged_lambda_windows 24 $ffstring -JOBNAME $jobname $fmp -TMPLAUNCHDIR -skip-leg complex -prepare > launch.sh


sed -i 's/Launch command: //g' launch.sh
sed -i 's/-RETRIES 1/-RETRIES 0/g' launch.sh
sed -i '/  fep_type =/a \ \ bennett.sliding_time.window=1000\n    bennett.sliding_time.begin=100\n    bennett.sliding_time.dt=1000' *_*.msj #set the sliding energy window to a 1ns length

printf "\n\nRun launch.sh to start the FEP for the solvent leg energy calculation.\n"

exit





else
printf "Detected mutations.txt, starting protein FEP.\n"
############ For starting protein MCFEP (solvent leg only), now unified in a single fep.sh file.  ############
default_mae=$(ls *.mae* | head -n 1)  # to get the first .mae or .maegz file if it is not specified by user
subhost=fgpu

random_seed=$((1000 + RANDOM % 9999))
for i in $1 $2 $3; do
if [[ "$i" == *"seed"* ]]; then
    extracted_number=$(echo $i | grep -o "[0-9]*")
    seed=$extracted_number
fi
if [[ "$i" == *"gpu"* ]]; then
    extracted_number=$(echo "$i" | grep -o "[0-9]*" )
    gpu=$extracted_number
fi
if [[ "$i" == "mae="* ]]; then
    usermae="${i#*=}"
fi
done
seed=${seed:-$random_seed}    ;    gpus=${gpu:-4} ; echo Random seed is $seed ;  echo Number of GPUs is $gpus 
mae=${usermae:-$default_mae}
fullfolder=$(basename `pwd`)
jobname=$fullfolder     #using the folder name as the default jobname
echo Input mae file is $mae


$SCHRODINGER/fep_plus -HOST localhost -SUBHOST $subhost -JOBNAME $jobname -ppj $gpus $mae -protein mutations.txt -solvent_asl "chain.name E" -skip-leg complex -time 25000 -seed $seed -prepare > launch.sh

sed -i 's/Launch command: //g' launch.sh
sed -i 's/-RETRIES 1/-RETRIES 0/g' launch.sh
sed -i '/  fep_type =/a \ \ bennett.sliding_time.window=1000\n    bennett.sliding_time.begin=100\n    bennett.sliding_time.dt=1000' *_*.msj #set the sliding energy window to a 1ns length

printf "\n\nRun launch.sh to start the FEP for the solvent leg energy calculation.\n"

fi


